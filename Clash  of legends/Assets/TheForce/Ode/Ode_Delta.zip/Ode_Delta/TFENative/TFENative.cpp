#include "TFENative.h"
#include <algorithm>
#include "assert.h"
#include "TFENative.h"

extern "C" {
	void TestSort(int a[], int length) {
		std::sort(a, a + length);
	}

	void Add(
		INT32 a,
		INT32 b,
		INT32* result)
	{
		*result = a + b;
	}

	// various common computations involving the matrix J
	// compute iMJ = inv(M)*J'
	static void compute_invM_JT(int m, Constraint *J, int nb, BodyInfo *binfo)
	{
		int i;
		for (i = 0; i < m; i++)
		{
			int b1 = J[i].b1;
			int b2 = J[i].b2;
			float k = binfo[b1].invMass;
			J[i].iMJ.J1l = J[i].J1l * k;
			J[i].iMJ.J1a = binfo[b1].invI.MultiplyVector(J[i].J1a);

			if (b2 >= 0)
			{
				k = binfo[b2].invMass;
				J[i].iMJ.J2l = J[i].J2l * k;
				J[i].iMJ.J2a = binfo[b2].invI.MultiplyVector(J[i].J2a);
			}
		}
	}

	const Vector3 zero = Vector3(0.f, 0.f, 0.f);
	
	// compute out = inv(M)*J'*in.
	static void multiply_invM_JT(int m, Constraint *J, int nb, BodyInfo *binfo)
	{
		int i;
		for (i = 0; i < nb; i++)
		{
			binfo[i].cforcel = zero;
			binfo[i].cforcea = zero;
		}

		for (i = 0; i < m; i++)
		{
			int b1 = J[i].b1;
			int b2 = J[i].b2;
			float lambda = J[i].lambda;
			binfo[b1].cforcel += J[i].iMJ.J1l * lambda;
			binfo[b1].cforcea += J[i].iMJ.J1a * lambda;

			if (b2 >= 0)
			{
				binfo[b2].cforcel += J[i].iMJ.J2l * lambda;
				binfo[b2].cforcea += J[i].iMJ.J2a * lambda;
			}
		}
	}

	void SOR_LCP_Native(int m, Constraint *J, int nb, BodyInfo *binfo, QuickStepParameters qs)
	{
		int num_iterations = qs.num_iterations;
		float sor_w = qs.w;     // SOR over-relaxation parameter

		int i, j;

		for (i = 0; i < m; i++)
		{
			J[i].lambda *= 0.9f;

			// a copy of the 'hi' vector in case findex[] is being used
			//memcpy (hicopy,hi,m*sizeof(float));
			J[i].Copy.hi = J[i].hi;
		}

		// precompute iMJ = inv(M)*J'
		compute_invM_JT(m, J, nb, binfo);

		// compute fc=(inv(M)*J')*lambda. we will incrementally maintain fc
		// as we change lambda.
		multiply_invM_JT(m, J, nb, binfo);

		// precompute 1 / diagonals of A
		for (i = 0; i < m; i++)
		{
			float sum = 0;
			sum += Vector3::Dot(J[i].iMJ.J1l, J[i].J1l) + Vector3::Dot(J[i].iMJ.J1a, J[i].J1a);
			if (J[i].b2 >= 0)
			{
				sum += Vector3::Dot(J[i].iMJ.J2l, J[i].J2l) + Vector3::Dot(J[i].iMJ.J2a, J[i].J2a);
			}
			J[i].Ad = sor_w / (sum + J[i].cfm);
		}

		// scale J and b by Ad
		for (i = 0; i < m; i++)
		{
			float Ad = J[i].Ad;
			J[i].J1l = J[i].J1l * Ad;
			J[i].J1a *= Ad;
			J[i].J2l *= Ad;
			J[i].J2a *= Ad;
			J[i].rhs *= Ad;
		}

		// scale Ad by CFM
		for (i = 0; i < m; i++) J[i].Ad *= J[i].cfm;

		// order to solve constraint rows in

		// make sure constraints with findex < 0 come first.
		j = 0;
		for (i = 0; i < m; i++) if (J[i].findex < 0) J[j++].order = i;
		for (i = 0; i < m; i++) if (J[i].findex >= 0) J[j++].order = i;
		assert(j == m);

		for (int iteration = 0; iteration < num_iterations; iteration++)
		{
			if ((iteration & 7) == 0)
			{
				for (i = 1; i < m; i++)
				{
					int tmp = J[i].order;
					int swapi = std::rand() % (i + 1);
					//dIASSERT(swapi < i + 1);
					//dIASSERT(swapi >= 0);
					J[i].order = J[swapi].order;
					J[swapi].order = tmp;
				}
			}

			for (i = 0; i < m; i++)
			{
				// @@@ potential optimization: we could pre-sort J and iMJ, thereby
				//     linearizing access to those arrays. hmmm, this does not seem
				//     like a win, but we should think carefully about our memory
				//     access pattern.

				int index = J[i].order;

				// set the limits for this constraint. note that 'hicopy' is used.
				// this is the place where the QuickStep method differs from the
				// direct LCP solving method, since that method only performs this
				// limit adjustment once per time step, whereas this method performs
				// once per iteration per constraint row.
				// the constraints are ordered so that all lambda[] values needed have
				// already been computed.
				if (J[index].findex >= 0)
				{
					J[index].hi = fabs(J[index].Copy.hi * J[J[index].findex].lambda);
					J[index].lo = -J[index].hi;
				}

				int b1 = J[index].b1;
				int b2 = J[index].b2;
				float delta = J[index].rhs - J[index].lambda * J[index].Ad;

				// @@@ potential optimization: SIMD-ize this and the b2 >= 0 case
				delta -= Vector3::Dot(binfo[b1].cforcel, J[index].J1l) + Vector3::Dot(binfo[b1].cforcea, J[index].J1a);
				// @@@ potential optimization: handle 1-body constraints in a separate
				//     loop to avoid the cost of test & jump?
				if (b2 >= 0)
				{
					delta -= Vector3::Dot(binfo[b2].cforcel, J[index].J2l) + Vector3::Dot(binfo[b2].cforcea, J[index].J2a);
				}

				// compute lambda and clamp it to [lo,hi].
				// @@@ potential optimization: does SSE have clamping instructions
				//     to save test+jump penalties here?
				float new_lambda = J[index].lambda + delta;
				if (new_lambda < J[index].lo)
				{
					delta = J[index].lo - J[index].lambda;
					J[index].lambda = J[index].lo;
				}
				else if (new_lambda > J[index].hi)
				{
					delta = J[index].hi - J[index].lambda;
					J[index].lambda = J[index].hi;
				}
				else
				{
					J[index].lambda = new_lambda;
				}

				//@@@ a trick that may or may not help
				//float ramp = (1-((float)(iteration+1)/(float)num_iterations));
				//delta *= ramp;

				// update fc.
				// @@@ potential optimization: SIMD for this and the b2 >= 0 case
				binfo[b1].cforcel += J[index].iMJ.J1l * delta;
				binfo[b1].cforcea += J[index].iMJ.J1a * delta;
				// @@@ potential optimization: handle 1-body constraints in a separate
				//     loop to avoid the cost of test & jump?
				if (b2 >= 0)
				{
					binfo[b2].cforcel += J[index].iMJ.J2l * delta;
					binfo[b2].cforcea += J[index].iMJ.J2a * delta;
				}
			}
		}
	}

	void *TF_dCreatePlane()
	{
		return dCreatePlane(NULL, 0.f, 1.f, 0.f, 0.f);
	}

	void *TF_dCreateSphere()
	{
		return dCreateSphere(NULL, 1.f);
	}

	void *TF_dCreateRay()
	{
		return dCreateRay(NULL, 1.f);
	}

	void *TF_dCreateBox()
	{
		return dCreateBox(NULL, 1.f, 1.f, 1.f);
	}

	void *TF_dCreateCapsule()
	{
		return dCreateCapsule(NULL, 1.f, 1.f);
	}

	void TF_dGeomPlaneSetParams(void *plane, Vector3 inNormal, float d)
	{
		dGeomPlaneSetParams((dGeomID)plane, inNormal.x, inNormal.y, inNormal.z, d);
	}

	void TF_dGeomSphereSetRadius(void *sphere, float radius)
	{
		dGeomSphereSetRadius((dGeomID)sphere, radius);
	}

	void TF_dGeomRaySetLength(void *ray, float length)
	{
		dGeomRaySetLength((dGeomID)ray, length);
	}

	void TF_dGeomBoxSetLengths(void *box, Vector3 lengths)
	{
		dGeomBoxSetLengths((dGeomID)box, lengths.x, lengths.y, lengths.z);
	}

	void TF_dGeomCapsuleSetParams(void *capsule, float radius, float length)
	{
		dGeomCapsuleSetParams((dGeomID)capsule, radius, length);
	}

	void TF_dGeomSetPosR(void *geom, Vector3 pos, Quaternion R)
	{
		dGeomSetPosition((dGeomID)geom, pos.x, pos.y, pos.z);
		Quaternion s;
		s.x = R.w;
		s.y = R.x;
		s.z = R.y;
		s.w = R.z;
		dGeomSetQuaternion((dGeomID)geom, (float*)&s);
	}

	void *TF_dGeomTriMeshDataBuildSingle(const Vector3* Vertices, INT32 VertexCount,const INT32* Indices, INT32 IndexCount)
	{
		dTriMeshDataID data = dGeomTriMeshDataCreate();
		dGeomTriMeshDataBuildSingle(data,
			Vertices, sizeof(Vector3), VertexCount,
			Indices, IndexCount, sizeof(INT32));

		return data;
	}

	void *TF_dCreateTriMesh(void* data)
	{
		dGeomID trimesh = dCreateTriMesh(NULL,
			(dTriMeshDataID)data,
			NULL,
			NULL,
			NULL);
		dGeomTriMeshEnableTC(trimesh, dSphereClass, false);
		dGeomTriMeshEnableTC(trimesh, dBoxClass, false);

		return trimesh;
	}

	int TF_dCollide(void *o1,  void *o2, int contactCount, dContactGeom *contact)
	{
		return dCollide((dGeomID)o1, (dGeomID)o2, contactCount, contact, sizeof(dContactGeom));
	}

	int TF_dInitODE()
	{
		dInitODE();
		return (int)sizeof(dContactGeom);
	}

	void TF_dCloseODE()
	{
		dCloseODE();
	}

	void TF_dGeomDestroy(void *geom)
	{
		dGeomDestroy((dGeomID)geom);
	}
}