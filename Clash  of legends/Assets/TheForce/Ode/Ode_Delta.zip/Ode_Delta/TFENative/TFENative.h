#pragma once

//#include "targetver.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <intrin.h>

#include <directxmath.h>
#include <directxcollision.h>
//#include "MathHelpers.h"
#include "ode/ode.h"

#define TFENATIVE_API __declspec(dllexport)

struct Vector3
{
	float x;
	float y;
	float z;

	inline Vector3(float x, float y, float z)
	{
		this->x = x;
		this->y = y;
		this->z = z;
	}

	inline static float Dot(const Vector3 &lhs, const Vector3 &rhs)
	{
		return lhs.x * rhs.x + lhs.y * rhs.y + lhs.z * rhs.z;
	}
/*
	static Vector3 Scale(Vector3 lhs, float d)
	{
		return Vector3(lhs.x * d, lhs.y * d, lhs.z * d);
	}
*/
	inline Vector3 operator*(float b) const { return Vector3(x*b,y*b,z*b); }

	void operator *=(float d)
	{
		x *= d;
		y *= d;
		z *= d;
	}

	void operator +=(const Vector3 &other)
	{
		x += other.x;
		y += other.y;
		z += other.z;
	}
};

struct Quaternion
{
	float w;
	float x;
	float y;
	float z;
};

struct Matrix4x4
{
	float m00;
	float m01;
	float m02;
	float m03;
	float m10;
	float m11;
	float m12;
	float m13;
	float m20;
	float m21;
	float m22;
	float m23;
	float m30;
	float m31;
	float m32;
	float m33;

	Vector3 MultiplyVector(Vector3 v) const
	{
		return Vector3(
			m00 * v.x + m01 * v.y + m02 * v.z,
			m10 * v.x + m11 * v.y + m12 * v.z,
			m20 * v.x + m21 * v.y + m22 * v.z
		);
	}
};

struct ConstraintCopy
{
	Vector3 J1l;
	Vector3 J1a;
	Vector3 J2l;
	Vector3 J2a;
	float hi;
};

struct ConstraintiMJ
{
	Vector3 J1l;
	Vector3 J1a;
	Vector3 J2l;
	Vector3 J2a;
};

struct Constraint
{
	static float fps;

	Vector3 J1l;
	Vector3 J1a;
	Vector3 J2l;
	Vector3 J2a;
	float c;
	float cfm;
	float lo;
	float hi;
	int findex;
	float rhs;
	float lambda;
	int b1;
	int b2;
	ConstraintCopy Copy;
	ConstraintiMJ iMJ;
	float Ad;
	int order;

	void CopyJ()
	{
		Copy.J1l = J1l;
		Copy.J1a = J1a;
		Copy.J2l = J2l;
		Copy.J2a = J2a;
	}
};

struct QuickStepParameters
{
	int num_iterations;      // number of SOR iterations to perform
	float w;                 // the SOR over-relaxation parameter
};

struct BodyInfo
{
	Matrix4x4 invI;
	float invMass;
	Vector3 tmp1l;
	Vector3 tmp1a;
	Vector3 cforcel;
	Vector3 cforcea;
};

extern "C" {
	TFENATIVE_API void TestSort(int a[], int length);
	TFENATIVE_API void Add(INT32 a,INT32 b,INT32* result);
	TFENATIVE_API void SOR_LCP_Native(int m, Constraint *J, int nb, BodyInfo *binfo, QuickStepParameters qs);
	TFENATIVE_API void *TF_dCreatePlane();
	TFENATIVE_API void *TF_dCreateSphere();
	TFENATIVE_API void *TF_dCreateRay();
	TFENATIVE_API void *TF_dCreateBox();
	TFENATIVE_API void *TF_dCreateCapsule();
	TFENATIVE_API void TF_dGeomPlaneSetParams(void *plane, Vector3 inNormal, float d);
	TFENATIVE_API void TF_dGeomSphereSetRadius(void *sphere, float radius);
	TFENATIVE_API void TF_dGeomRaySetLength(void *ray, float length);
	TFENATIVE_API void TF_dGeomBoxSetLengths(void *box, Vector3 lengths);
	TFENATIVE_API void TF_dGeomCapsuleSetParams(void *capsule, float radius, float length);
	TFENATIVE_API void TF_dGeomSetPosR(void *geom, Vector3 pos, Quaternion R);
	TFENATIVE_API void *TF_dGeomTriMeshDataBuildSingle(const Vector3* Vertices, INT32 VertexCount,const INT32* Indices, INT32 IndexCount);
	TFENATIVE_API void *TF_dCreateTriMesh(void* data);
	TFENATIVE_API int TF_dCollide(void *o1, void *o2, int contactCount, dContactGeom *contact);
	TFENATIVE_API int TF_dInitODE();
	TFENATIVE_API void TF_dCloseODE();
	TFENATIVE_API void TF_dGeomDestroy(void *geom);
}
